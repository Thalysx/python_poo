from jogador import jogador
from abc import ABC, abstractmethod

class golpes(ABC):
    @abstractmethod
    def golpear(self, j: jogador):
        pass

class Soco(golpes):
    def golpear(self, j: jogador):
        j.energia = -1
        print(f"Soco! jogador agora tem energia {j.energia}.")

class chute(golpes):
    def golpear(self, j: jogador):
        j.energia -= 2
        print(f'Chute! jogador agora tem energia{j.energia}.')  
         