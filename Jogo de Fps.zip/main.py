from golpes import Soco, chute
from jogador import jogador

if __name__ == "__main__":
    j1 = jogador()
    print(j1)

    s1 = Soco()
    c1 = chute()

    s1.golpear(j1)  
    c1.golpear(j1)  

    print(j1)