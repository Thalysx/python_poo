from abc import ABC, abstractmethod

class jogador(ABC):
    def __init__(self):
        self.energia = 150.0
        self.armas : List[Arma] = []


    def atirar(self, d, j):
        d.disparar(j)

def municiar(self, d: Disparavel):

    def bater(self, j, g : Golpe = None, a: Arma = None):
        if g == None and a != None
           a.agredir(j)
        elif a == None and g != None
        g.golpear(j)


    def __str__(self):
        return f"jogador com energia {self.energia}"
    

