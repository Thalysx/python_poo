from jogador import jogador
from abc import ABC, abstractmethod

class Disparavel(ABC):
    @abstractmethod
    def disparar(self, jogador: jogador):
        pass

    @abstractmethod
    def recarregar(self):
        pass

class Faca:
    def __init__(self):
        super().__init__(destruicao = 15)
        self.lamina = 10
    
    def agredir(self, jogador: jogador):
        if self.lamina > 0:
            jogador.energia -= self.destruicao
            self.lamina -= 1  
            print(f"Ataque com faca! jogador agora tem energia {jogador.energia}. Lâmina agora tem fio {self.lamina}.")
        else:
        
            print("A lâmina da faca está sem fio. O ataque não foi eficaz.")
    
    def __str__(self):
        return f"Faca com lâmina {self.lamina} e poder de destruição {self.destruicao}"


class Arma(ABC):
    def __init__(self, destruicao: float):
        self.destruicao = destruicao

    @abstractmethod
    def agredir(self, jogador: jogador):
        jogador.energia -= self.destruicao

    def __str__(self):
        return f"Arma com poder de destruição {self.destruicao}"

class Revolver(Arma, Disparavel):
      
    def __init__(self):
          self.cartuchos = 6
          self.destruicao = 20
    
    def disparar (self, j: jogador):
        if self.cartuchos > 0:
            jogador.energia -= self.destruicao
            self.cartuchos -= 1
            print(f"Revolver disparado! jogador agora tem energia {jogador.energia}. Cartuchos restantes: {self.cartuchos}")
        else:
            print("Revolver sem cartuchos, recarregue!")
    
    def recarregar(self):
        self.cartuchos = 6
        print("Revolver recarregado!")

class Lanca_Chamas(Disparavel):
    def __init__(self):
        self.gas = 100.0
        self.destruicao = 30
    
    def disparar(self, j: jogador):
        if self.gas >= 5:
            jogador.energia -= self.destruicao
            self.gas -= 5
            print(f"Lança-chamas disparado! jogador agora tem energia {jogador.energia}. Gás restante: {self.gas}%")
        else:
            print("Lança-chamas sem gás, recarregue!")
    
    def recarregar (self):
        self.gas = 100.0
        print("Lança-chamas recarregado")

class Soco_Ingles(soco, Arma):
    def __init__(self):
        Arma.__init__(self, destruicao=5)
    def agredir(self, jogador: jogador):
        super().golpear(jogador)
        print(f"Soco inglês! jogador agora tem energia {jogador.energia}.")