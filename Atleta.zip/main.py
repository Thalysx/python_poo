from atleta import *

if __name__ == "__main__":


    bolt= Corredor("bolt",38,86.2)
    print(bolt)
    print(bolt.aquecer())
    print(bolt.correr())

    cielo = Nadador("cielo",35,56.6)
    print(cielo)
    print(cielo.aquecer())
    print(cielo.nadar())

    avacini = Ciclista("avcini",35,67.2)
    print(avacini)
    print(avacini.aquecer())
    print(avacini.pedalar())

    k = Triatleta("fernanda",45,76.9)
    print(k)