from abc import ABC, abstractmethod

class Atleta(ABC):
    def __init__(self, nome: str, idade: int, peso: float):
        self.nome = nome
        self.idade = idade
        self.peso = peso

    def aquecer(self):
        return "Aquecendo...\n"

    def __str__(self):
        info = f'Nome: {self.nome}, '
        info += f'Idade: {self.idade} anos, '
        info += f'Peso: {self.peso:.2f} Kg'
        return info


class Corredor(ABC):
    def correr(self):
        return "Correndo...\n"


class Nadador(ABC):
    def nadar(self):
        return "Nadando...\n"


class Ciclista(ABC):
    def pedalar(self):
        return "Pedalando...\n"


class Triatleta(Atleta, Corredor, Nadador, Ciclista):
    def correr(self):
        return "Correndo...\n"

    def nadar(self):
        return "Nadando...\n"

    def pedalar(self):
        return "Pedalando...\n"

    def realizar_maratona(self):
        info = self.aquecer()
        info += self.nadar()
        info += self.pedalar()
        info += self.correr()
        return info

if __name__ == "__main__":
    Fujii = Triatleta("Gabriel Fujii",40, 55, 8)
    print(Fujii.realizar_maratona())
    print(Triatleta. __mro__)
