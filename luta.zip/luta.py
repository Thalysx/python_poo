Anderson Silva deu um soco em Fabrício Werdum! Energia de Fabrício Werdum: 94.5
Fabrício Werdum aplicou um gancho em Anderson Silva! Energia de Anderson Silva: 79.2
Anderson Silva aplicou um cruzado em Fabrício Werdum! Energia de Fabrício Werdum: 84.3
Fabrício Werdum aplicou um chute alto em Anderson Silva! Energia de Anderson Silva: 63.8
Anderson Silva aplicou um Superman Punch em Fabrício Werdum! Energia de Fabrício Werdum: 31.1
Fabrício Werdum aplicou uma chave de braço em Anderson Silva! Energia de Anderson Silva: -36.2

Situação Final:
Lutador: Anderson Silva, Energia: -36.2
Lutador: Fabrício Werdum, Energia: 31.1
